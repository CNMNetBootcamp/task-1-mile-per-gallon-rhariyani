# Task 1: Miles per Gallon #

## Details: ##
Create a program that asks the user for the number of miles traveled and the amount of gas used. Calculate the miles per gallon.

## Requirements ##
1. Turn in a Psuedocode document
2. Turn in a Raptor document
3. Turn in a C# console or forms based application
