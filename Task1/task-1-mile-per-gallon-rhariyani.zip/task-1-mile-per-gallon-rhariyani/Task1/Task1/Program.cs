﻿using System;

namespace Task1
{
    class Program
    {
        static void Main(string[] args)
        {
           
            double miles = 0.0;
            double gas = 0.0;
            double startmiles = 0.0;
            double endmiles = 0.0;



            //input
            Console.WriteLine("Please enter starting Miles:");
            startmiles = Single.Parse(Console.ReadLine());
            Console.WriteLine("Please enter Ending Miles:");
            endmiles = Single.Parse(Console.ReadLine());
            Console.WriteLine("Please enter Gasoline Used:");
             gas = Single.Parse(Console.ReadLine());

            //Process

            miles = endmiles - startmiles / gas;

            //output    
            Console.WriteLine("Total miles per gallon is " + miles);
            Console.ReadLine();
        }
    }
}
