


   // The Miles per Gallon Formula is:
//(E-S)/G
//Where:
//S= Miles at the start of the tank(when filled first)
//E= Miles at the end of the tank(when refilled)
//G= Gallons used


   // input
    "Enter your starting Miles?"
    "Enter Your ending Miles?"
"Enter your Gallon used?"



//process

  Total Miles= E-S/G

    //output

  put  "Miles per Gallon is" + Total Miles